<?php
function init_decoder()
{
	return 0;
}

function decode_string($line,$k)
{
	return $line;
}
?>
